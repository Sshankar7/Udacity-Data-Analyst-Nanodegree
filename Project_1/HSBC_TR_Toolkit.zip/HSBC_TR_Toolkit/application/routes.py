from application import app, auth, Config, functions, CCR_Function
from flask import render_template, make_response, send_from_directory, request, json, Response
from werkzeug.utils import secure_filename
import os, time
import pandas as pd

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/dashboard', methods=['GET','POST'])
@auth.auth_required
def dashboard():
    return render_template('dashboard.html', dashboard=True, flag=functions.file_contents(), data=functions.path_data(), regions_list=functions.regions_list())

@app.route('/static/uploads/<path:filename>')
@auth.auth_required
def download_file(filename):
    return send_from_directory(os.path.join(Config.BASE_DIR,Config.UPLOAD_FOLDER), filename=filename, as_attachment=True)

@app.route('/upload_file', methods=['POST'])
@auth.auth_required
def upload_file():
    if request.method == "POST":
        file = request.files['path_file']
        if file and functions.allowed_file(file.filename):
            #filename = secure_filename(file.filename)
            filename = "Path_Updates.csv"
            file.save(os.path.join(Config.BASE_DIR, Config.UPLOAD_FOLDER, filename))
            return "Upload Success"
        else:
            return "Upload Error"
    else:
        return "Error"
 
@app.route('/mi_info_process', methods=['POST'])
@auth.auth_required
def process_mi_info():
    if request.method == "POST":
        data = {}
        data['mi_type'] = request.form['sel_week_mon']
        data['otc_exp_cob'] = request.form['otc_exp_cob']
        data['otc_sensi_cob'] = request.form['otc_sensi_cob']
        data['exp_stavros_cob'] = request.form['exp_stavros_cob']
        data['sensi_stavros_cob'] = request.form['sensi_stavros_cob']
        data['prev_sensi_cob'] = request.form['prev_sensi_cob']
        processFilePath = os.path.join(Config.BASE_DIR, Config.PROCESSING_FOLDER)
        if os.path.exists(processFilePath):
            with open(processFilePath +'/mi_infos.json','w') as mi_file:
                json.dump(data, mi_file)
            return "MI Success"
        else:
            return "MI Error"
    else:
        return "Error"

@app.route('/start_process', methods=['POST'])
@auth.auth_required
def process_start():
    mi_infos_file_path = os.path.join(Config.BASE_DIR, Config.PROCESSING_FOLDER, "mi_infos.json")
    if os.path.exists(mi_infos_file_path):
        # Import CCR Access Python Function 
        CCR_Function.Global_EUC(mi_infos_file_path)
       
        return "Start Success"
    else:
        return "MIInfo File Error"


@app.route('/logout')
def logout():
    mi_infos_file_path = os.path.join(Config.BASE_DIR, Config.PROCESSING_FOLDER, "mi_infos.json")
    if os.path.exists(mi_infos_file_path):
        # Remove MI_Info json file on logout
        os.remove(mi_infos_file_path)
    return make_response(render_template('login.html'), 401, {'WWW-Authenticate':'Basic Realm = "Login Required"'})

@app.errorhandler(404)
def page_not_found(error):
    return render_template('error_pages/404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('error_pages/500.html'), 500

@app.errorhandler(400)
def bad_request(error):
    return render_template('error_pages/400.html'), 400

@app.errorhandler(401)
def unauthorized(error):
    return render_template('error_pages/401.html'), 401

@app.errorhandler(403)
def forbidden(error):
    return render_template('error_pages/403.html'), 403

@app.errorhandler(405)
def method_not_allowed(error):
    return render_template('error_pages/405.html'), 405

@app.errorhandler(503)
def service_unavailable(error):
    return render_template('error_pages/503.html'), 503


@app.route('/progress')
def progress():
	def generate():
		x = 0
		
		while x <= 100:
			yield "data:" + str(x) + "\n\n"
			x = x + 10
			time.sleep(0.07)

	return Response(generate(), mimetype= 'text/event-stream')