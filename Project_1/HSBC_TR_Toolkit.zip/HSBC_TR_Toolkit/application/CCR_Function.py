from flask import json
import pandas as pd

def Global_EUC(mi_infos_file_path):

    with open(mi_infos_file_path, 'r') as mi_info_file:
        mi_infos = json.load(mi_info_file)    
    mi_type = mi_infos['mi_type']
    otc_exp_cob = mi_infos['otc_exp_cob']
    otc_sensi_cob = mi_infos['otc_sensi_cob']
    exp_stavros_cob = mi_infos['exp_stavros_cob']
    sensi_stavros_cob = mi_infos['sensi_stavros_cob']
    prev_sensi_cob = mi_infos['prev_sensi_cob']

    df = pd.read_csv("/Users/sshankar7/OneDrive/Personal_Work/Zbay_Ecommerce-WNS_Analytics_Wizard/train.csv")
    #df1 = pd.read_excel("/Users/sshankar7/OneDrive/Personal_Work/gtd/gtd_14to17_0718dist.xlsx")
    print(df.shape)
    yield 1
    """
    Code Segment for Global EUC 
    """