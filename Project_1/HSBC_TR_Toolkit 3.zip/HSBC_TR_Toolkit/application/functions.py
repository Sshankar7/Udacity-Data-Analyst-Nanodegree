from csv import reader 
from application import Config
from flask import Response, json, stream_with_context
import pandas as pd
import os 

filename = "Path_Updates.csv"
UPLOADED_PATH = os.path.join(Config.BASE_DIR, Config.UPLOAD_FOLDER, filename)
ALLOWED_EXTENSIONS = {'csv'}

def file_contents():
    df = pd.read_csv(UPLOADED_PATH)
    if df['File Paths'].isnull().sum() < 1:
        return 'upPaths'
    else:
        return ''
    
def path_data():
    df = pd.read_csv(UPLOADED_PATH)
    return df.values

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def regions_list():
    path = os.path.join(Config.BASE_DIR, Config.APP_STATIC_FOLDER)
    region_file = pd.read_csv(path+"/REGIONS_LIST.csv")
    return region_file


def progress(current,total):
    def generate(current, total):
        x = 0
        x = int((current/total)*100)
        #print(x)
        yield str(x)
        
    return generate(current, total)