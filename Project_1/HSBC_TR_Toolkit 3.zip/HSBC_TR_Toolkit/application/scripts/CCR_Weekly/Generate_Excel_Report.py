from flask import json
from application import Config, functions, modals
import pandas as pd
import os, time

def Excel_Report(start_time,cob,mul_regions,scen_1,scen_2,scen_3,scen_4):
    """
    * Change Script Progress Table Data To Reset Current Count for Progress Bar
    * Define Total Function Counts to the Progress 
    """
    current_count = 0
    total_count = 1
    modals.reset_progress(current_count,total_count)

    """
    Do Something. . . 
    """
    # Call Progress Counter for Updating Progress Bar
    current_count += 1
    modals.progress_counter(start_time,current_count) 