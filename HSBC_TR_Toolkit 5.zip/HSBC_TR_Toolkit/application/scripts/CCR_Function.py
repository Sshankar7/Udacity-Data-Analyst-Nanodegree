from flask import json
from application import Config, functions, modals
import pandas as pd
import os, time

def Global_EUC(start_time):
    """
    * Change Script Progress Table Data To Reset Current Count for Progress Bar
    * Define Total Function Counts to the Progress 
    """
    start_status = 'Processing'
    current_count = 0
    total_count = 2
    modals.reset_start_status(start_status)
    modals.reset_progress(current_count,total_count)

    """
    Code Segment for Global EUC 
    """

    #df = pd.read_csv("/Users/sshankar7/OneDrive/Personal_Work/Zbay_Ecommerce-WNS_Analytics_Wizard/train.csv")
    #print("DF Shape",df.shape)
    
    # Call Progress Counter for Updating Progress Bar
    current_count += 1
    modals.progress_counter(start_time,current_count)
    
    
    #df1 = pd.read_excel("/Users/sshankar7/OneDrive/Personal_Work/gtd/gtd_14to17_0718dist.xlsx")
    #print("DF1 shape",df1.shape)

    # Call Progress Counter for Updating Progress Bar
    current_count += 1
    modals.progress_counter(start_time,current_count)    

def Export_Exp_Report(start_time):
    """
    * Change Script Progress Table Data To Reset Current Count for Progress Bar
    * Define Total Function Counts to the Progress 
    """
    current_count = 0
    total_count = 1
    modals.reset_progress(current_count,total_count)


    #df1 = pd.read_excel("/Users/sshankar7/OneDrive/Personal_Work/gtd/gtd_14to17_0718dist.xlsx")
    #print("DF1 shape",df1.shape)
    """
    Do Something. . . 
    """
    # Call Progress Counter for Updating Progress Bar
    current_count += 1
    modals.progress_counter(start_time,current_count)


def Export_Cmb_Report(start_time):
    """
    * Change Script Progress Table Data To Reset Current Count for Progress Bar
    * Define Total Function Counts to the Progress 
    """
    current_count = 0
    total_count = 1
    modals.reset_progress(current_count,total_count)

    """
    Do Something. . . 
    """
    # Call Progress Counter for Updating Progress Bar
    current_count += 1
    modals.progress_counter(start_time,current_count)


def Export_CRDIV_Report(start_time):
    """
    * Change Script Progress Table Data To Reset Current Count for Progress Bar
    * Define Total Function Counts to the Progress 
    """
    current_count = 0
    total_count = 1
    modals.reset_progress(current_count,total_count)

    
    """
    Do Something. . . 
    """
    # Call Progress Counter for Updating Progress Bar
    current_count += 1
    modals.progress_counter(start_time,current_count)