import os, sqlite3, time
from flask import g
from application import Config, app

AUTH_DATABASE = os.path.join(Config.BASE_DIR,Config.APP_DIR,Config.REQ_STATIC_DIR,".auth_info.db")
PROC_DATABASE = os.path.join(Config.BASE_DIR,Config.APP_DIR,Config.STATIC_DIR,Config.PROCESSING_DIR, "hsbctrtoolkit.db")

def auth_get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(AUTH_DATABASE)
        #db.row_factory = sqlite3.Row
    return db


def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(PROC_DATABASE)
        #db.row_factory = sqlite3.Row
    return db


@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()



def make_dicts(cursor, row):
    return dict((cursor.description[idx][0], value)
                for idx, value in enumerate(row))

#db.row_factory = make_dicts


def query_db(query, args=(), one=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv


def write_db(query, args, msg_var):
    try:
        cur = get_db().execute(query, args)
        get_db().commit()
        msg = f"Record {msg_var} successfully!"
    except:
        get_db().rollback()
        msg = f"Error in {msg_var} record!"
    finally:
        cur.close()
        return msg


def truncate_db(query, args=()):
    try:
        cur = get_db().execute(query, args)
        get_db().commit()
        msg = "Record deleted successfully!"
    except:
        get_db().rollback()
        msg = "Error in deleting record!"
    finally:
        cur.close()
        return msg


def reset_progress(current_count, total_count):
    query = "SELECT current_count, total_fn_count, elapsed_time from script_progress WHERE script_id = ?"
    rv = query_db(query, [1], one=True)
    if rv is None:
        insert_query = "INSERT INTO script_progress (script_id, current_count, total_fn_count, elapsed_time) VALUES (?,?,?,?)"
        insert_args = (1,current_count,total_count,0)
        msg = write_db(insert_query,insert_args,"added")
        print("Progress Reset",msg)
    else:
        up_qry = "UPDATE script_progress SET current_count = ?, total_fn_count = ?, elapsed_time = ? WHERE script_id = ?"
        up_args = (current_count,total_count,0,1)
        msg = write_db(up_qry, up_args,"updated")
        print("Progress Reset",msg)
        

def reset_start_status(start_status):
    query = "SELECT start_status FROM mi_infos WHERE mi_id = ?"
    rv = query_db(query, [1], one=True)
    if rv is None:
        insert_query = "INSERT INTO mi_infos (mi_id, start_status) VALUES (?,?)"
        insert_args = (1,start_status)
        msg = write_db(insert_query,insert_args,"added")
        print("Start Status Reset",msg)
    else:
        up_qry = "UPDATE mi_infos SET start_status = ? WHERE mi_id = ?"
        up_args = (start_status,1)
        msg = write_db(up_qry, up_args,"updated")
        print("Start Status Reset",msg)

def progress_counter(start_time,current_count):
    elapsed_time = round((time.time() - start_time)/60,2)
    update_query = "UPDATE script_progress SET current_count = ?, elapsed_time = ? WHERE script_id = ?"
    update_args = (current_count,elapsed_time,1)
    msg = write_db(update_query, update_args,"updated")
    print("Progress Counter",msg)