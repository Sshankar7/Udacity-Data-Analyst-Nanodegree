$(document).ready(function () {
    $(".custom-file-input").on("change", function() {
        var fileName = $(this).val().split("\\").pop();
        $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
      });
    $('input:radio').click(function() {
        if ($("#sel-week-mon1").prop("checked")) {$("#crdiv-rep").addClass("d-none");}
        else {$("#crdiv-rep").removeClass("d-none");} });


    $.validator.addMethod( "extension", function( value, element, param ) {
        param = typeof param === "string" ? param.replace( /,/g, "|" ) : "png|jpe?g|gif";
        return this.optional( element ) || value.match( new RegExp( "\\.(" + param + ")$", "i" ) );
    }, $.validator.format( "Please select file with a valid extension." ) );

    // Select Path Form
    $("#upload_paths_form").validate({
        rules: {
            path_file: {
                required: true,
                extension: 'csv'
            },
        },
        messages: {
            path_file: {
                required: "Please provide a .csv file.",
                extension: "Plese select file with a .csv extension only.",
              },
        },
        submitHandler: function (form) {
            var $form_data = new FormData($('#upload_paths_form')[0]);
            $.ajax({
                url: "/upload_file",
                type: "post",
                data: $form_data,
                processData: false,
                contentType: false,
                success: postEventActivity,
                error: postEventActivity
            });
            return false; // required to block normal submit since you used ajax
        }
    });
    // MI-Info Form
    $("#mi_info_form").validate({
        rules: {
            sel_week_mon: {
                required: true,
            },
            otc_exp_cob: {
                required: true
            },
            otc_sensi_cob: {
                required: true
            },
            exp_stavros_cob: {
                required: true
            },
            sensi_stavros_cob: {
                required: true
            },
            prev_sensi_cob: {
                required: true
            },
        },
        submitHandler: function (form) {
            var $form_data = new FormData($('#mi_info_form')[0]);
            $.ajax({
                url: "/mi_info_process",
                type: "post",
                data: $form_data,
                processData: false,
                contentType: false,
                success: postEventActivity,
                error: postEventActivity
            });
            return false; // required to block normal submit since you used ajax
        }
    });

    // Start Form
    $("#start_form").validate({
        rules: {
            site_select: {
                required: true,
            },
            scenarios_select: {
                required: true
            },
            risk_factor_select: {
                required: true
            },
        },
        submitHandler: function (form) {
            var $form_data = new FormData($('#start_form')[0]);
            getProgress('.start-progress','.start-progress-label','.start-elapsed-time');
            $.ajax({
                url: "/start_process",
                type: "post",
                data: $form_data,
                processData: false,
                contentType: false,
                success: postEventActivity,
                error: postEventActivity
            });
            return false; // required to block normal submit since you used ajax
        }
    });

    // Export Excel Report Form - Generate Exposure Report Button
    $("#exp_rep_btn").click(function(e){
        e.preventDefault();
        getProgress('.expo-progress','.expo-progress-label','.expo-elapsed-time');
        $.ajax({
            url: "/expo_rep_process",
            type: "post",
            data: false,
            processData: false,
            contentType: false,
            success: postEventActivity,
            error: postEventActivity
        });
    });
    // Export Excel Report Form - Generate Combined Report Button
    $("#cmb_rep_btn").click(function(e){
        e.preventDefault();
        getProgress('.cmb-progress','.cmb-progress-label','.cmb-elapsed-time');
        $.ajax({
            url: "/cmb_rep_process",
            type: "post",
            data: false,
            processData: false,
            contentType: false,
            success: postEventActivity,
            error: postEventActivity
        });
    });
    // Export Excel Report Form - Generate Exposure Report Button
    $("#crdiv_rep_btn").click(function(e){
        e.preventDefault();
        $.ajax({
            url: "/crdiv_status",
            type: "post",
            data: false,
            processData: false,
            contentType: false,
            success: function(response,status,xhr) {
                if (response == 'True'){
                    getProgress('.crdiv-progress','.crdiv-progress-label','.crdiv-elapsed-time');
                    $.ajax({
                        url: "/crdiv_rep_process",
                        type: "post",
                        data: false,
                        processData: false,
                        contentType: false,
                        success: postEventActivity,
                        error: postEventActivity
                    });}
                else{postEventActivity("MIType Not Monthly");}}
        });
    });

    // Excel EUC Form
    $("#excel_euc_form").validate({
        rules: {
            sel_regions_multiple: {
                required: true,
            },
            cob: {
                required: true,
            }
        },
        submitHandler: function (form) {
            $.ajax({
                url: "/crdiv_status",
                type: "post",
                data: false,
                processData: false,
                contentType: false,
                success: function(response,status,xhr) {
                    if (response == 'False'){
                        var $form_data = new FormData($('#excel_euc_form')[0]);
                        getProgress('.exl-rep-progress','.exl-rep-progress-label','.exl-rep-elapsed-time');
                        $.ajax({
                            url: "/excel_rep_process",
                            type: "post",
                            data: $form_data,
                            processData: false,
                            contentType: false,
                            success: postEventActivity,
                            error: postEventActivity
                        });}
                    else{postEventActivity("MIType Not Weekly");}}
            });
            return false; // required to block normal submit since you used ajax
        }
    });

});



function postEventActivity(response) {
    if (response != "Error") {
    if (response == "Upload Success") {$type = "success"; $icon = "fa fa-check mr-5"; $message = "File uploaded successfully!";}
    else if (response == "Upload Error") {$type = "danger"; $icon = "fa fa-times mr-5"; $message = "Oops! Failed to upload file.";}
    else if (response == "MI Success") {$type = "success"; $icon = "fa fa-check mr-5"; $message = "MI Info has been set."}
    else if (response == "MI Error") {$type = "danger"; $icon = "fa fa-times mr-5"; $message = "Oops! Error in setting MI Info."}
    else if (response == "Start Success") {$type = "success"; $icon = "fa fa-check mr-5"; $message = "Process has completed successfully."}
    else if (response == "Start Error") {$type = "danger"; $icon = "fa fa-times mr-5"; $message = "Oops! Error occurred in start process."}
    else if (response == "MIInfo Not Set") {$type = "danger"; $icon = "fa fa-times mr-5"; $message = "MI Info hasn't been set! Kindly set the MI Info before proceeding."}
    else if (response == "Exposure Report Success") {$type = "success"; $icon = "fa fa-check mr-5"; $message = "Exposure Report has been generated successfully."}
    else if (response == "Exposure Report Error") {$type = "danger"; $icon = "fa fa-times mr-5"; $message = "Oops! Error occurred in generating Exposure Report."}
    else if (response == "Start Not Run") {$type = "danger"; $icon = "fa fa-times mr-5"; $message = "Start hasn't been ran! Kindly run Start before generating reports."}
    else if (response == "Combined Report Success") {$type = "success"; $icon = "fa fa-check mr-5"; $message = "Combined Report has been generated successfully."}
    else if (response == "Combined Report Error") {$type = "danger"; $icon = "fa fa-times mr-5"; $message = "Oops! Error occurred in generating Combined Report."}
    else if (response == "CRDIV Report Success") {$type = "success"; $icon = "fa fa-check mr-5"; $message = "CRDIV Report has been generated successfully."}
    else if (response == "CRDIV Report Error") {$type = "danger"; $icon = "fa fa-times mr-5"; $message = "Oops! Error occurred in generating CRDIV Report."}
    else if (response == "MIType Not Monthly") {$type = "danger"; $icon = "fa fa-times mr-5"; $message = "MI Type hasn't been set to monthly! Kindly set the MI Type to month and re-run Start."}
    else if (response == "MIType Not Weekly") {$type = "danger"; $icon = "fa fa-times mr-5"; $message = "MI Type hasn't been set to weekly! Kindly set the MI Type to week and re-run Start."}
    else if (response == "Excel Report Success") {$type = "success"; $icon = "fa fa-check mr-5"; $message = "Excel Report has been generated successfully."}
    else if (response == "Excel Report Error") {$type = "danger"; $icon = "fa fa-times mr-5"; $message = "Oops! Error occurred in generating Excel Report."}
    

        Codebase.helpers('notify', {
            align: 'right',
            from: 'top',
            type: $type,
            icon: $icon,
            message: $message
        });
    } else {
        Codebase.helpers('notify', {
            align: 'right',
            from: 'top',
            type: 'danger',
            icon: 'fa fa-times mr-5',
            timer: 0,
            message: 'Oops! An error has occured.'
        });
    }

}

function blockToggle(showId, hideIds) {
    var hideIds = hideIds.split(" ");
    var i;
    for (i = 0; i < hideIds.length; i++) {
        Codebase.blocks(hideIds[i], 'close');
    }
    Codebase.blocks(showId, 'block_toggle');
}
jQuery(function(){ if ($("#upPaths")) {$("#upPaths").removeClass("d-none");} });

function getProgress(progressBar,progressBarLabel,elapsedTime) {
    var source = new EventSource("/progress");
	source.onmessage = function(event) {
        console.log(event.data);
        var resData = JSON.parse(event.data);
        if(resData.msg == 'No Data' && resData.pct == '0'){
            source.close()
        }
        else {
            $(progressBar).css('width', resData.pct+'%').attr('aria-valuenow', resData.pct);
            $(progressBarLabel).text(resData.pct+'%');
            $(elapsedTime).text(resData.elapsed_time+' Minutes');

            if(resData.pct == '100'){
                source.close()
            }
        }
	}
  }