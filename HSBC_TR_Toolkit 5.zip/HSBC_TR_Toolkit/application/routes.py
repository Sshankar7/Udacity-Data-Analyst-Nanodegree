from application import app, Config, functions, modals
from .scripts import CCR_Function
from .scripts.CCR_Weekly import Generate_Excel_Report
from flask import render_template, session, make_response, redirect, url_for, send_from_directory, request, json, Response, stream_with_context, flash, escape
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
import os, time
import pandas as pd


@app.route('/')
def login():
    if not session.get('logged_in') is None:
        return redirect(url_for("dashboard"))
    else:
        return render_template('login.html')

@app.route('/authenticate', methods=['POST'])
def authenticate_user():
    if request.method == "POST":
        query = "SELECT password FROM users WHERE username = ?"
        username = escape(request.form['username'])
        password = escape(request.form['password'])
        try:
            cur = modals.auth_get_db().execute(query, [username])
        except Exception as e:
            flash("Something went wrong!")
            print("Database Error:",e)
            return redirect(url_for("login"))
        rv = cur.fetchall()
        cur.close()
        if rv:
            if check_password_hash(rv[0][0],password):
                session['logged_in'] = username 
                return redirect(url_for("dashboard"))
            else:
                flash("Incorrect Username/Password")
                print("Dash_Login")
                return redirect(url_for("login"))
        else:
            flash("Incorrect Username/Password")
            print("RV_Login")
            return redirect(url_for("login"))
    else:
        print("Last_Login")
        return redirect(url_for("login"))
    


@app.route('/dashboard', methods=['GET','POST'])
def dashboard():
    if not session.get('logged_in') is None:
        return render_template('dashboard.html', dashboard=True, flag=functions.file_contents(), data=functions.path_data(), regions_list=functions.regions_list())
    else:
        flash("You're not logged in!")
        return redirect(url_for("login"))

@app.route('/static/uploads/<path:filename>')
def download_file(filename):
    return send_from_directory(os.path.join(Config.BASE_DIR,Config.APP_DIR,Config.STATIC_DIR,Config.UPLOAD_DIR), filename=filename, as_attachment=True)

@app.route('/upload_file', methods=['POST'])
def upload_file():
    if request.method == "POST":
        file = request.files['path_file']
        if file and functions.allowed_file(file.filename):
            #filename = secure_filename(file.filename)
            filename = "Path_Updates.csv"
            file.save(os.path.join(Config.BASE_DIR,Config.APP_DIR,Config.STATIC_DIR,Config.UPLOAD_DIR, filename))
            return "Upload Success"
        else:
            return "Upload Error"
    else:
        return "Error"
 
@app.route('/mi_info_process', methods=['POST'])
def process_mi_info():
    if request.method == "POST":
        try:
            query = "SELECT mi_type, otc_exp_cob, otc_sensi_cob, exp_stavros_cob, sensi_stavros_cob, prev_sensi_cob from mi_infos WHERE mi_id = ?"
            rv = modals.query_db(query, [1], one=True)
            if rv is None:
                insert_query = "INSERT INTO mi_infos (mi_id, mi_type, otc_exp_cob, otc_sensi_cob, exp_stavros_cob, sensi_stavros_cob, prev_sensi_cob) VALUES (?,?,?,?,?,?,?)"
                insert_args = (1,escape(request.form['sel_week_mon']),escape(request.form['otc_exp_cob']),escape(request.form['otc_sensi_cob']),escape(request.form['exp_stavros_cob']),escape(request.form['sensi_stavros_cob']),escape(request.form['prev_sensi_cob']))
                msg = modals.write_db(insert_query,insert_args,"added")
                print("MI Infos",msg)
            else:
                up_qry = "UPDATE mi_infos SET mi_type=?, otc_exp_cob=?, otc_sensi_cob=?, exp_stavros_cob=?, sensi_stavros_cob=?, prev_sensi_cob=? WHERE mi_id = ?"
                up_args = (escape(request.form['sel_week_mon']),escape(request.form['otc_exp_cob']),escape(request.form['otc_sensi_cob']),escape(request.form['exp_stavros_cob']),escape(request.form['sensi_stavros_cob']),escape(request.form['prev_sensi_cob']),1)
                msg = modals.write_db(up_qry, up_args,"updated")
                print("MI Infos",msg)
            return "MI Success"
        except:
            return "MI Error"
    else:
        return "Error"

@app.route('/start_process', methods=['POST'])
def process_start():
    start_time = time.time()
    if request.method == "POST":
        try:
            query = "SELECT mi_type, otc_exp_cob, otc_sensi_cob, exp_stavros_cob, sensi_stavros_cob, prev_sensi_cob from mi_infos WHERE mi_id = ?"
            rv = modals.query_db(query, [1], one=True)
            if rv is not None:
                query = "SELECT sites, scenarios, risk_factors from start WHERE start_id = ?"
                rv2 = modals.query_db(query, [1], one=True)
                if rv2 is None:
                    print("start_insert")
                    insert_query = "INSERT INTO start (start_id, sites, scenarios, risk_factors) VALUES (?,?,?,?)"
                    insert_args = (1,escape(request.form['site_select']),escape(request.form['scenarios_select']),escape(request.form['risk_factor_select']))
                    msg = modals.write_db(insert_query,insert_args,"added")
                    print("Start Process",msg)
                else:
                    print("update_start")
                    up_qry = "UPDATE start SET sites=?,scenarios=?,risk_factors=? WHERE start_id = ?"
                    up_args = (escape(request.form['site_select']),escape(request.form['scenarios_select']),escape(request.form['risk_factor_select']),1)
                    msg = modals.write_db(up_qry, up_args,"updated")
                    print("Start Process",msg)
                
                # Import CCR Access Python Function 
                CCR_Function.Global_EUC(start_time)
                
                up_qry = "UPDATE mi_infos SET start_status = ? WHERE mi_id = ?"
                # Check if MI Type is set to Monthly
                if rv[0] == 2:
                    up_args = ('start_completed_monthly',1)
                else:
                    up_args = ('start_completed_weekly',1)
                msg = modals.write_db(up_qry, up_args,"updated")
                print(msg)

                return "Start Success"
            else:
                return "MIInfo Not Set"
        except Exception as e:
            return "Start Error",e
    else:
        return "Start Error"

@app.route('/expo_rep_process', methods=['POST'])
def exposure_report():
    start_time = time.time()
    if request.method == "POST":
        try:
            query = "SELECT start_status FROM mi_infos WHERE mi_id = ?"
            rv = modals.query_db(query, [1], one=True)
            if rv is not None:
                if (rv[0] == 'start_completed_weekly') or (rv[0] == 'start_completed_monthly'):
                    # Import Export Exposure Report Function
                    CCR_Function.Export_Exp_Report(start_time)

                    return "Exposure Report Success"
                else:
                    return "Start Not Run"
            else:
                return "MIInfo Not Set"
        except Exception as e:
            return "Exposure Report Error",e
    else:
        return "Exposure Report Error"


@app.route('/cmb_rep_process', methods=['POST'])
def combined_report():
    start_time = time.time()
    if request.method == "POST":
        try:
            query = "SELECT start_status FROM mi_infos WHERE mi_id = ?"
            rv = modals.query_db(query, [1], one=True)
            if rv is not None:
                if (rv[0] == 'start_completed_weekly') or (rv[0] == 'start_completed_monthly'):    
                    # Import Export Combined Report Function
                    CCR_Function.Export_Cmb_Report(start_time)

                    return "Combined Report Success"
                else:
                    return "Start Not Run"
            else:
                return "MIInfo Not Set"
        except Exception as e:
            return "Combined Report Error",e
    else:
        return "Combined Report Error"


@app.route('/crdiv_status', methods=['POST'])
def crdiv_status():
    if request.method == "POST":
        query = "SELECT mi_type, start_status FROM mi_infos WHERE mi_id = ?"
        rv = modals.query_db(query,[1], one=True)
        if (rv is not None) and (rv[0] == 2) and (rv[1] == "start_completed_monthly"):
            return 'True'
        else:
            return 'False'

@app.route('/crdiv_rep_process', methods=['POST'])
def crdiv_report():
    start_time = time.time()
    if request.method == "POST":
        try:
            query = "SELECT start_status, mi_type FROM mi_infos WHERE mi_id = ?"
            rv = modals.query_db(query, [1], one=True)
            if rv is not None:
                if rv[0] == 'start_completed_monthly':
                    if rv[1] == 2:
                        # Import Export CRDIV Report Function
                        CCR_Function.Export_CRDIV_Report(start_time)

                        return "CRDIV Report Success"
                    else:
                        return "MIType Not Monthly"
                else:
                    return "Start Not Run"
            else:
                return "MIInfo Not Set"
        except Exception as e:
            return "CRDIV Report Error",e
    else:
        return "CRDIV Report Error"


@app.route('/excel_rep_process', methods=['POST'])
def process_excel_rep():
    start_time = time.time()
    if request.method == "POST":
        try:
            query = "SELECT mi_type FROM mi_infos WHERE mi_id = ?"
            rv = modals.query_db(query, [1], one=True)
            if rv is not None:
                if rv[0] == 1:
                    cob = escape(request.form['cob'])
                    mul_regions = escape(request.form.getlist('sel_regions_multiple'))
                    scen_1, scen_2 = escape(request.form['scenario1']), escape(request.form['scenario2'])
                    scen_3, scen_4 = escape(request.form['scenario3']), escape(request.form['scenario4'])
                    print(scen_1,scen_2,scen_3,scen_4)

                    # Call Generate Excel Report Function
                    Generate_Excel_Report.Excel_Report(start_time,cob,mul_regions,scen_1,scen_2,scen_3,scen_4)

                    return "Excel Report Success"
                else:
                    return "MIType Not Weekly"
            else:
                return "MIType Not Set"
        except Exception as e:
            return "Excel Report Error",e
    else:
        return "Excel Report Error"


@app.route('/logout')
def logout():
    table_names = ['mi_infos','start','script_progress']
    for table_name in table_names:
        query = f"DELETE FROM {table_name}"
        msg = modals.truncate_db(query)
        print(table_name,msg)
    session.pop('logged_in', None)
    return redirect(url_for('login'))

@app.errorhandler(404)
def page_not_found(error):
    return render_template('error_pages/404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('error_pages/500.html'), 500

@app.errorhandler(400)
def bad_request(error):
    return render_template('error_pages/400.html'), 400

@app.errorhandler(401)
def unauthorized(error):
    return render_template('error_pages/401.html'), 401

@app.errorhandler(403)
def forbidden(error):
    return render_template('error_pages/403.html'), 403

@app.errorhandler(405)
def method_not_allowed(error):
    return render_template('error_pages/405.html'), 405

@app.errorhandler(503)
def service_unavailable(error):
    return render_template('error_pages/503.html'), 503


@app.route('/progress')
def progress():
    def generate():
        x, data = 0, {}
        query = "SELECT current_count, total_fn_count, elapsed_time from script_progress WHERE script_id = ?"
        time.sleep(1)
        rv = modals.query_db(query, [1], one=True)
        if (rv is not None):
            print("Current {}, Total {}".format(rv[0],rv[1]))
            x = int((rv[0]/rv[1])*100)
            data['msg'] = 'Status Fine'
            data['pct'] = str(x)
            data['elapsed_time'] = str(rv[2])
            print(data)
            yield "data: " + json.dumps(data) + "\n\n"
        
        else:
            data['msg'] = 'No Data'
            data['pct'] = '0'
            data['elapsed_time'] = '0'
            print(data)
            yield "data: " + json.dumps(data) + "\n\n"
            
    return Response(stream_with_context(generate()), mimetype= 'text/event-stream')

